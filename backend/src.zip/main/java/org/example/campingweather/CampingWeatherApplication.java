package org.example.campingweather;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CampingWeatherApplication {

    public static void main(String[] args) {
        SpringApplication.run(CampingWeatherApplication.class, args);
    }

}
